// src/components/home/PopularDestinations.tsx
import { Link } from 'react-router-dom'
import { cities } from '@/data/cities'

export function PopularDestinations() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-16">
      <h2 className="text-2xl font-bold text-neutral-900">مقصدهای محبوب</h2>
      <p className="mt-1 text-neutral-600">پرطرفدارترین شهرها برای اقامت</p>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {cities.map((city) => (
          <Link
            key={city.id}
            to={`/hotels?destination=${city.id}`}
            className="group relative aspect-3/4 overflow-hidden rounded-lg"
          >
            <img
              src={city.image}
              alt={city.name}
              loading="lazy"
              className="h-full w-full object-cover transition group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-linear-to-t from-neutral-900/70 via-transparent to-transparent" />
            <div className="absolute inset-x-0 bottom-0 p-3 text-white">
              <p className="font-semibold">{city.name}</p>
              <p className="text-xs text-white/80">{city.country}</p>
            </div>
          </Link>
        ))}
      </div>
    </section>
  )
}