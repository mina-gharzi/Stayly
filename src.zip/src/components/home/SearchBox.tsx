// src/components/home/SearchBox.tsx
import { useState, type FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search } from 'lucide-react'
import { cities } from '@/data/cities'
import { Button } from '@/components/ui/Button'
import { GuestSelector, type GuestValue } from '@/components/ui/GuestSelector'

export function SearchBox() {
  const navigate = useNavigate()
  const [destination, setDestination] = useState('')
  const [checkIn, setCheckIn] = useState('')
  const [checkOut, setCheckOut] = useState('')
  const [guests, setGuests] = useState<GuestValue>({ adults: 2, children: 0, rooms: 1 })

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const params = new URLSearchParams()
    if (destination) params.set('destination', destination)
    if (checkIn) params.set('checkIn', checkIn)
    if (checkOut) params.set('checkOut', checkOut)
    params.set('adults', String(guests.adults))
    params.set('children', String(guests.children))
    params.set('rooms', String(guests.rooms))
    params.set('page', '1')
    navigate(`/hotels?${params.toString()}`)
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="grid w-full max-w-4xl grid-cols-1 gap-3 rounded-lg bg-white p-4 text-start shadow-elevated sm:grid-cols-2 lg:grid-cols-5 lg:items-end"
    >
      <div className="flex flex-col gap-1.5 lg:col-span-2">
        <label htmlFor="destination" className="text-sm font-medium text-neutral-800">مقصد</label>
        <select
          id="destination"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          className="h-11 rounded-md border border-neutral-200 px-3 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
        >
          <option value="">همه مقصدها</option>
          {cities.map((city) => (
            <option key={city.id} value={city.id}>{city.name}, {city.country}</option>
          ))}
        </select>
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="checkIn" className="text-sm font-medium text-neutral-800">ورود</label>
        <input
          id="checkIn"
          type="date"
          value={checkIn}
          onChange={(e) => setCheckIn(e.target.value)}
          className="ltr-content h-11 rounded-md border border-neutral-200 px-3 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <label htmlFor="checkOut" className="text-sm font-medium text-neutral-800">خروج</label>
        <input
          id="checkOut"
          type="date"
          value={checkOut}
          onChange={(e) => setCheckOut(e.target.value)}
          className="ltr-content h-11 rounded-md border border-neutral-200 px-3 text-sm text-neutral-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
        />
      </div>

      <div className="flex flex-col gap-1.5">
        <span className="text-sm font-medium text-neutral-800">مهمانان</span>
        <GuestSelector value={guests} onChange={setGuests} />
      </div>

      <Button type="submit" className="lg:col-span-5">
        <Search className="h-4 w-4" aria-hidden />
        جستجوی هتل
      </Button>
    </form>
  )
}