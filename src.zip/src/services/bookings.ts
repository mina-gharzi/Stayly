// src/services/bookings.ts
import type { Booking } from '@/types'

const STORAGE_KEY = 'stayly-created-bookings'

function generateBookingId(): string {
  return `STY-${Math.floor(10000 + Math.random() * 90000)}`
}

export function createBooking(booking: Omit<Booking, 'id' | 'createdAt'>): Promise<Booking> {
  return new Promise((resolve) => {
    setTimeout(() => {
      const newBooking: Booking = { ...booking, id: generateBookingId(), createdAt: new Date().toISOString() }
      const existing: Booking[] = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]')
      localStorage.setItem(STORAGE_KEY, JSON.stringify([...existing, newBooking]))
      resolve(newBooking)
    }, 300)
  })
}

export function getCreatedBookingById(id: string): Booking | undefined {
  const existing: Booking[] = JSON.parse(localStorage.getItem(STORAGE_KEY) ?? '[]')
  return existing.find((b) => b.id === id)
}