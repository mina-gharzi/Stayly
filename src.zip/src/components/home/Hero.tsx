// src/components/home/Hero.tsx
import heroImage from '@/assets/hero.jpg' 
import { SearchBox } from './SearchBox'

export function Hero() {
  return (
    <section className="relative">
      <div className="absolute inset-0 -z-10">
        <img src={heroImage} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-neutral-900/50" />
      </div>
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-8 px-4 py-24 text-center text-white">
        <div>
          <h1 className="text-3xl font-bold sm:text-4xl">اقامتگاه بعدی‌تان را همین‌جا پیدا کنید</h1>
          <p className="mt-2 text-white/80">جستجو در هتل‌ها، استراحتگاه‌ها و اقامتگاه‌های بوتیک در ۵ مقصد محبوب</p>
        </div>
        <SearchBox />
      </div>
    </section>
  )
}