// src/App.tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { Layout } from '@/components/layout/Layout'
import { ProtectedRoute } from '@/components/auth/ProtectedRoute'
import { Home } from '@/pages/Home'
import { Hotels } from '@/pages/Hotels'
import { HotelDetails } from '@/pages/HotelDetails'
import { Booking } from '@/pages/Booking'
import { Checkout } from '@/pages/Checkout'
import { Confirmation } from '@/pages/Confirmation'
import { Login } from '@/pages/Login'
import { Register } from '@/pages/Register'

const queryClient = new QueryClient()

function ComingSoon({ label }: { label: string }) {
  return (
    <div className="mx-auto flex max-w-7xl flex-col items-center justify-center px-4 py-24 text-center">
      <p className="text-lg font-medium text-neutral-800">{label}</p>
      <p className="mt-1 text-sm text-neutral-600">این بخش در فاز بعدی پیاده‌سازی می‌شود.</p>
    </div>
  )
}

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/hotels" element={<Hotels />} />
            <Route path="/hotels/:hotelId" element={<HotelDetails />} />
            <Route path="/booking/:hotelId" element={<Booking />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/confirmation/:bookingId" element={<Confirmation />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Register />} />

            <Route element={<ProtectedRoute />}>
              <Route path="/my-bookings" element={<ComingSoon label="رزروهای من" />} />
              <Route path="/my-bookings/:bookingId" element={<ComingSoon label="جزئیات رزرو" />} />
              <Route path="/profile" element={<ComingSoon label="پروفایل" />} />
              <Route path="/favorites" element={<ComingSoon label="علاقه‌مندی‌ها" />} />
            </Route>
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  )
}